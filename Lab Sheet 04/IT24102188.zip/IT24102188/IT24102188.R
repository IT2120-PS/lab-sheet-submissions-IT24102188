getwd()
setwd("C:\\Users\\it24102188\\Desktop\\IT24102188")


#Q1
branch_data <- read.csv("Exercise.txt", header=TRUE)
head(branch_data)

#Q2
str(branch_data)

#Q3
boxplot(branch_data$Sales_X1, main="Boxplot of Sales", ylab="Sales")

#Q4
fivenum(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

#Q5
find_outliers <- function(x) {
  q1 <- quantile(x, 0.25, na.rm=TRUE)
  q3 <- quantile(x, 0.75, na.rm=TRUE)
  iqr <- q3 - q1
  lower <- q1 - 1.5 * iqr
  upper <- q3 + 1.5 * iqr
  outliers <- x[x < lower | x > upper]
  return(outliers)
}
