#Question 1

setwd("C:\\Users\\ASUS\\Desktop\\IT24102188")

Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)

str(Delivery_Times)

names(Delivery_Times) <- "Delivery_Time"

attach(Delivery_Times)


#Question 2


histogram <- hist(Delivery_Time, 
                  main = "Histogram of Delivery Times", 
                  xlab = "Delivery Time (minutes)",
                  breaks = seq(20, 70, length = 10), 
                  right = FALSE,
                  col = "lightblue")



#Question 3

breaks <- round(histogram$breaks)
freq <- histogram$counts
cum.freq <- cumsum(freq)

new <- c(0, cum.freq) # Start with 0 cumulative frequency

plot(breaks, new, 
     type = "l", 
     main = "Cumulative Frequency Polygon (Ogive) for Delivery Times",
     xlab = "Delivery Time (minutes)", 
     ylab = "Cumulative Frequency",
     ylim = c(0, max(cum.freq) + 5),
     col = "blue", lwd = 2)

points(breaks, new, col = "red", pch = 16)

grid()

cumulative_table <- cbind(Upper_Limit = breaks, Cumulative_Frequency = new)
print(cumulative_table)