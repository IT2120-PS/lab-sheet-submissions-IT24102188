setwd("C:\\Users\\ASUS\\Desktop\\IT24102188")
weights <- read.table("C:\\Users\\ASUS\\Desktop\\Probability and statistics\\Lab Sheets\\Lab Sheet 8\\Exercise - LaptopsWeights.txt", header=TRUE)$Weight.kg


#Question 1


weights <- c(2.46, 2.45, 2.47, 2.71, 2.46, 2.05, 2.6, 2.42, 2.43, 2.53, 2.57, 2.85, 2.7, 2.53, 2.28, 2.2, 2.57, 2.89, 2.51, 2.47, 2.66, 2.06, 2.41, 2.65, 2.76, 2.43, 2.61, 2.57, 2.73, 2.17, 2.67, 2.05, 1.71, 2.32, 2.23, 2.76, 2.7, 2.13, 2.75, 2.2)


pop_mean <- mean(weights)


pop_var <- var(weights) * (length(weights) - 1) / length(weights)


pop_sd <- sqrt(pop_var)

print(pop_mean)
print(pop_sd)



#Question 2

set.seed(123)


samples <- NULL
for (i in 1:25) {
  samples <- cbind(samples, sample(weights, 6, replace = TRUE))
}
colnames(samples) <- paste("S", 1:25, sep="")


s_means <- apply(samples, 2, mean)
s_sds <- apply(samples, 2, sd)

print(s_means)
print(s_sds)



#Question 3

mean_of_means <- mean(s_means)
sd_of_means <- sd(s_means)

print(mean_of_means)
print(sd_of_means)

theoretical_se <- pop_sd / sqrt(6)
print(theoretical_se)