setwd("C:\\Users\\ASUS\\Desktop\\IT24102188")

set.seed(123)

baking_times <- rnorm(25, mean=45, sd=2)

print(baking_times)





sample_mean <- mean(baking_times)

pop_sd <- 2
hyp_mean <- 46
n <- 25


se <- pop_sd / sqrt(n)


z_stat <- (sample_mean - hyp_mean) / se

p_value <- pnorm(z_stat)


if (p_value < 0.05) {
  decision <- "Reject H0: There is sufficient evidence that the average baking time is less than 46 minutes."
} else {
  decision <- "Fail to reject H0: There is not sufficient evidence that the average baking time is less than 46 minutes."
}

cat("Sample Mean:", sample_mean, "\n")
cat("Z-statistic:", z_stat, "\n")
cat("P-value:", p_value, "\n")
cat("Decision:", decision, "\n")